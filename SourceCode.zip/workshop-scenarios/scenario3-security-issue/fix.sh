#!/bin/bash
# Scenario 3: Fix - Remove exposed credentials

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
APP_YML="$REPO_ROOT/PetAdoptions/petsearch-java/src/main/resources/application.yml"
SECRETS_FILE="$REPO_ROOT/PetAdoptions/petsearch-java/src/main/resources/secrets.properties"
GITIGNORE="$REPO_ROOT/PetAdoptions/petsearch-java/.gitignore"

echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║  Scenario 3: Fix - Removing Exposed Credentials                  ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""

# Restore application.yml
if [ -f "$APP_YML.backup" ]; then
    mv "$APP_YML.backup" "$APP_YML"
    echo "✅ Restored application.yml from backup"
else
    echo "⚠️  No backup found for application.yml - creating clean version"
    cat > "$APP_YML" << 'EOF'
server:
  port: 80

logging:
  level:
    root: INFO
    ca.petsearch: DEBUG
EOF
fi

# Remove secrets file
if [ -f "$SECRETS_FILE" ]; then
    rm "$SECRETS_FILE"
    echo "✅ Removed secrets.properties"
fi

# Add to gitignore if not already there
if [ -f "$GITIGNORE" ]; then
    if ! grep -q "secrets.properties" "$GITIGNORE"; then
        echo "" >> "$GITIGNORE"
        echo "# Security: Never commit secrets" >> "$GITIGNORE"
        echo "secrets.properties" >> "$GITIGNORE"
        echo "*.secret" >> "$GITIGNORE"
        echo "✅ Added secrets.properties to .gitignore"
    fi
else
    cat > "$GITIGNORE" << 'EOF'
# Security: Never commit secrets
secrets.properties
*.secret
*.pem
*.key

# Build artifacts
build/
*.jar
EOF
    echo "✅ Created .gitignore with security exclusions"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "⚠️  IMPORTANT: If these were real credentials, you should:"
echo ""
echo "   1. 🔄 Rotate all exposed credentials IMMEDIATELY"
echo "   2. 🔍 Check git history and use BFG Repo-Cleaner to remove secrets"
echo "   3. 📊 Review AWS CloudTrail for any unauthorized access"
echo "   4. 🔐 Move secrets to AWS Secrets Manager or SSM Parameter Store"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📤 Push the fix:"
echo ""
echo "   git add -A"
echo "   git commit -m 'security: remove hardcoded credentials, use Secrets Manager'"
echo "   git push origin main"
