#!/bin/bash
# Scenario 1: Build Failure - Dependency Version Conflict
# This script injects a Spring Boot version incompatible with Java 11
#
# DevOps Agent GitHub Integration Demo:
# - DevOps Agent receives deployment event from GitHub
# - Build fails in CodePipeline/CodeBuild
# - Agent correlates failure with the commit that changed build.gradle

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
BUILD_GRADLE="$REPO_ROOT/PetAdoptions/petsearch-java/build.gradle"

echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║  Scenario 1: Build Failure - Dependency Version Conflict         ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""
echo "📋 Story: A developer upgrades Spring Boot without checking Java compatibility"
echo ""

# Backup original file
cp "$BUILD_GRADLE" "$BUILD_GRADLE.backup"

# Replace Spring Boot version
if [[ "$OSTYPE" == "darwin"* ]]; then
    sed -i '' "s/id 'org.springframework.boot' version '2.7.3'/id 'org.springframework.boot' version '3.2.0'/" "$BUILD_GRADLE"
else
    sed -i "s/id 'org.springframework.boot' version '2.7.3'/id 'org.springframework.boot' version '3.2.0'/" "$BUILD_GRADLE"
fi

echo "✅ Injection complete!"
echo ""
echo "📁 Modified: PetAdoptions/petsearch-java/build.gradle"
echo "   Changed: Spring Boot 2.7.3 → 3.2.0"
echo "   Problem: Spring Boot 3.x requires Java 17+, project uses Java 11"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📤 Push the change to trigger the pipeline:"
echo ""
echo "   git add PetAdoptions/petsearch-java/build.gradle"
echo "   git commit -m 'chore: upgrade Spring Boot to 3.2.0 for latest features'"
echo "   git push origin main"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🔍 DevOps Agent Investigation Prompt:"
echo ""
echo "   'The PetSearch service deployment failed. Check the recent code"
echo "    changes in the GitHub repository and identify what caused the"
echo "    build failure.'"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🛠️  To fix: ./workshop-scenarios/scenario1-build-failure/fix.sh"
