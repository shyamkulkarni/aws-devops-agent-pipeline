#!/bin/bash
# Scenario 2: Fix - Remove the environment variable check

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
CONTROLLER="$REPO_ROOT/PetAdoptions/petsearch-java/src/main/java/ca/petsearch/controllers/SearchController.java"

echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║  Scenario 2: Fix - Removing Environment Variable Check           ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""

if [ -f "$CONTROLLER.backup" ]; then
    mv "$CONTROLLER.backup" "$CONTROLLER"
    echo "✅ Restored SearchController.java from backup"
else
    echo "❌ No backup found. Please manually remove the EXTERNAL_API_KEY check"
    echo "   from SearchController.java"
    exit 1
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📤 Push the fix:"
echo ""
echo "   git add PetAdoptions/petsearch-java/src/main/java/ca/petsearch/controllers/SearchController.java"
echo "   git commit -m 'fix: remove external API dependency that was not configured'"
echo "   git push origin main"
