#!/bin/bash
# Destroy One Observability Workshop stack and clean up dependencies
set -e

STACK_NAME="DevOpsAgent-Pipeline-Workshop"
REGION="us-east-1"

echo "=== Destroying $STACK_NAME ==="

# Get VPC ID from stack if it exists
VPC_ID=$(aws cloudformation describe-stack-resources \
  --stack-name "$STACK_NAME" \
  --region "$REGION" \
  --query 'StackResources[?ResourceType==`AWS::EC2::VPC`].PhysicalResourceId' \
  --output text 2>/dev/null || echo "")

if [ -n "$VPC_ID" ] && [ "$VPC_ID" != "None" ]; then
  echo "Found VPC: $VPC_ID"
  
  # Delete any ENIs in the VPC (CodeBuild leaves these behind)
  echo "Cleaning up ENIs..."
  ENIS=$(aws ec2 describe-network-interfaces \
    --filters "Name=vpc-id,Values=$VPC_ID" \
    --region "$REGION" \
    --query 'NetworkInterfaces[?Status==`available`].NetworkInterfaceId' \
    --output text 2>/dev/null || echo "")
  
  for ENI in $ENIS; do
    echo "  Deleting ENI: $ENI"
    aws ec2 delete-network-interface --network-interface-id "$ENI" --region "$REGION" 2>/dev/null || true
  done
fi

# Delete the CloudFormation stack
echo "Deleting CloudFormation stack..."
aws cloudformation delete-stack --stack-name "$STACK_NAME" --region "$REGION" 2>/dev/null || true

echo "Waiting for stack deletion..."
aws cloudformation wait stack-delete-complete --stack-name "$STACK_NAME" --region "$REGION" 2>/dev/null || {
  echo "Stack deletion may have failed. Checking for orphaned resources..."
  
  # If VPC still exists, clean it up manually
  if [ -n "$VPC_ID" ]; then
    echo "Cleaning up VPC $VPC_ID..."
    
    # Delete subnets
    for SUBNET in $(aws ec2 describe-subnets --filters "Name=vpc-id,Values=$VPC_ID" --region "$REGION" --query 'Subnets[].SubnetId' --output text 2>/dev/null); do
      echo "  Deleting subnet: $SUBNET"
      aws ec2 delete-subnet --subnet-id "$SUBNET" --region "$REGION" 2>/dev/null || true
    done
    
    # Delete security groups (except default)
    for SG in $(aws ec2 describe-security-groups --filters "Name=vpc-id,Values=$VPC_ID" --region "$REGION" --query 'SecurityGroups[?GroupName!=`default`].GroupId' --output text 2>/dev/null); do
      echo "  Deleting security group: $SG"
      aws ec2 delete-security-group --group-id "$SG" --region "$REGION" 2>/dev/null || true
    done
    
    # Delete VPC
    echo "  Deleting VPC: $VPC_ID"
    aws ec2 delete-vpc --vpc-id "$VPC_ID" --region "$REGION" 2>/dev/null || true
  fi
  
  # Force delete stack with retained resources
  aws cloudformation delete-stack \
    --stack-name "$STACK_NAME" \
    --region "$REGION" \
    --retain-resources NoIngressSecurityGroup PrivateSubnet1 VPC 2>/dev/null || true
}

echo ""
echo "=== Cleanup complete ==="
