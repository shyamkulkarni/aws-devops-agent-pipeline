package ca.petsearch;

public interface RandomNumberGenerator {
    int nextNonNegativeInt(int max);
}
