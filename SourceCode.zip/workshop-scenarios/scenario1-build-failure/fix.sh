#!/bin/bash
# Scenario 1: Fix - Revert Spring Boot version

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
BUILD_GRADLE="$REPO_ROOT/PetAdoptions/petsearch-java/build.gradle"

echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║  Scenario 1: Fix - Reverting Spring Boot Version                 ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""

if [ -f "$BUILD_GRADLE.backup" ]; then
    mv "$BUILD_GRADLE.backup" "$BUILD_GRADLE"
    echo "✅ Restored build.gradle from backup"
else
    # Manual fix
    if [[ "$OSTYPE" == "darwin"* ]]; then
        sed -i '' "s/id 'org.springframework.boot' version '3.2.0'/id 'org.springframework.boot' version '2.7.3'/" "$BUILD_GRADLE"
    else
        sed -i "s/id 'org.springframework.boot' version '3.2.0'/id 'org.springframework.boot' version '2.7.3'/" "$BUILD_GRADLE"
    fi
    echo "✅ Reverted Spring Boot version to 2.7.3"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📤 Push the fix:"
echo ""
echo "   git add PetAdoptions/petsearch-java/build.gradle"
echo "   git commit -m 'fix: revert Spring Boot to 2.7.3 for Java 11 compatibility'"
echo "   git push origin main"
