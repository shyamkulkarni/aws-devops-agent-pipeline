# DevOps Agent Pipeline Integration Scenarios

These scenarios demonstrate how AWS DevOps Agent integrates with GitHub to detect code changes, receive deployment events, and correlate them with operational incidents.

## Prerequisites

### 1. Fork the Repository to GitHub

Fork `aws-samples/one-observability-demo` to your GitHub account or organization:
- Go to https://github.com/aws-samples/one-observability-demo
- Click "Fork" and select your account/organization

### 2. Register GitHub with DevOps Agent (Account-Level)

1. Sign in to the AWS Management Console
2. Navigate to the AWS DevOps Agent console
3. Go to the **Capabilities** tab
4. In the **Pipeline** section, click **Add**
5. Select **GitHub** from the list
6. Choose connection type (User or Organization)
7. Complete the GitHub OAuth flow to install the AWS DevOps Agent GitHub app
8. Select repositories to grant access (include your forked `one-observability-demo` repo)

### 3. Connect Repository to Agent Space

1. In the DevOps Agent console, select your Agent Space
2. Go to **Capabilities** tab → **Pipeline** section
3. Click **Add** → Select **GitHub**
4. Select your forked `one-observability-demo` repository
5. Click **Add** to complete the connection

### 4. Deploy the Application

Deploy the One Observability Workshop to create the ECS services:

```bash
# Clone your fork
git clone https://github.com/YOUR_USERNAME/one-observability-demo.git
cd one-observability-demo

# Deploy via CloudFormation (creates CodePipeline)
aws cloudformation create-stack --stack-name Observability-Workshop \
  --template-body file://codepipeline-stack.yaml \
  --capabilities CAPABILITY_NAMED_IAM \
  --parameters ParameterKey=UserRoleArn,ParameterValue=$(aws iam get-role --role-name $(aws sts get-caller-identity --query Arn --output text | awk -F/ '{print $(NF-1)}') --query Role.Arn --output text) \
  ParameterKey=GithubUser,ParameterValue=YOUR_USERNAME
```

### 5. Associate AWS Resources with Deployments

In your Agent Space, associate the deployed ECS services with the GitHub repository so DevOps Agent can correlate deployments with incidents.

---

## Scenario 1: Build Failure After Code Change

**Objective:** Push a code change that breaks the build. DevOps Agent detects the deployment failure and correlates it with the recent commit.

### The Story

A developer upgrades Spring Boot to version 3.x without realizing the project uses Java 11 (Spring Boot 3.x requires Java 17+).

### Inject the Issue

```bash
cd one-observability-demo
./workshop-scenarios/scenario1-build-failure/inject.sh
```

This modifies `PetAdoptions/petsearch-java/build.gradle` to use an incompatible Spring Boot version.

### Push the Change

```bash
git add PetAdoptions/petsearch-java/build.gradle
git commit -m "chore: upgrade Spring Boot to 3.2.0 for latest features"
git push origin main
```

### What DevOps Agent Sees

1. **Deployment Event**: GitHub sends a deployment event to DevOps Agent
2. **Build Failure**: CodePipeline/CodeBuild fails during compilation
3. **Correlation**: DevOps Agent correlates the failure with the recent commit

### Investigation Prompt

```
The PetSearch service deployment failed. Check the recent code changes 
in the GitHub repository and identify what caused the build failure.
```

### Expected DevOps Agent Response

- Identifies the recent commit that changed `build.gradle`
- Shows the Spring Boot version change from 2.7.3 to 3.2.0
- Explains Java 11 incompatibility with Spring Boot 3.x
- Recommends reverting to Spring Boot 2.7.3 or upgrading to Java 17

### Fix

```bash
./workshop-scenarios/scenario1-build-failure/fix.sh
git add PetAdoptions/petsearch-java/build.gradle
git commit -m "fix: revert Spring Boot to 2.7.3 for Java 11 compatibility"
git push origin main
```

---

## Scenario 2: Deployment Succeeds but Service Fails

**Objective:** Push a code change that compiles successfully but causes runtime failures. DevOps Agent correlates the service errors with the recent deployment.

### The Story

A developer adds a feature that requires an environment variable, but forgets to add it to the ECS task definition. The build passes, deployment succeeds, but the service crashes at runtime.

### Inject the Issue

```bash
cd one-observability-demo
./workshop-scenarios/scenario2-runtime-failure/inject.sh
```

This adds code that checks for `EXTERNAL_API_KEY` environment variable.

### Push the Change

```bash
git add PetAdoptions/petsearch-java/src/main/java/ca/petsearch/controllers/SearchController.java
git commit -m "feat: integrate external API for enhanced pet search"
git push origin main
```

### What DevOps Agent Sees

1. **Deployment Event**: GitHub sends deployment event (status: success)
2. **Service Errors**: CloudWatch logs show RuntimeException
3. **Correlation**: DevOps Agent links the errors to the recent deployment

### Investigation Prompt

```
The PetSearch service is returning 500 errors. A deployment completed 
successfully 30 minutes ago. Investigate if the recent code changes 
are related to the current service failures.
```

### Expected DevOps Agent Response

- Checks recent deployments from GitHub integration
- Finds the commit that added EXTERNAL_API_KEY check
- Retrieves CloudWatch logs showing "Missing required configuration: EXTERNAL_API_KEY"
- Correlates the error with the code change
- Recommends adding the environment variable to ECS task definition or removing the check

### Fix

```bash
./workshop-scenarios/scenario2-runtime-failure/fix.sh
git add PetAdoptions/petsearch-java/src/main/java/ca/petsearch/controllers/SearchController.java
git commit -m "fix: remove external API dependency that was not configured"
git push origin main
```

---

## Scenario 3: Security Issue in Code Change

**Objective:** Push a code change containing hardcoded credentials. DevOps Agent can review the commit and flag security concerns.

### The Story

A developer accidentally commits configuration files with hardcoded API keys and database credentials.

### Inject the Issue

```bash
cd one-observability-demo
./workshop-scenarios/scenario3-security-issue/inject.sh
```

This creates files with fake credentials to demonstrate security scanning.

### Push the Change

```bash
git add -A
git commit -m "feat: add external service configuration"
git push origin main
```

### What DevOps Agent Sees

1. **Deployment Event**: GitHub sends deployment event
2. **Code Access**: DevOps Agent can read repository contents
3. **Security Patterns**: Detects credential patterns in committed files

### Investigation Prompt

```
Review the recent commits to the PetAdoptions repository. 
Check if any sensitive information like API keys, passwords, 
or AWS credentials have been committed to the codebase.
```

### Expected DevOps Agent Response

- Retrieves recent commits from GitHub
- Scans changed files for credential patterns
- Flags:
  - Hardcoded API key in `application.yml`
  - Database credentials in plain text
  - AWS credentials in `secrets.properties`
- Recommends:
  - Using AWS Secrets Manager or SSM Parameter Store
  - Adding `secrets.properties` to `.gitignore`
  - Rotating any exposed credentials immediately
  - Using git-filter-branch or BFG to remove secrets from history

### Fix

```bash
./workshop-scenarios/scenario3-security-issue/fix.sh
git add -A
git commit -m "security: remove hardcoded credentials, use Secrets Manager"
git push origin main
```

---

## Summary

| Scenario | Issue Type | Deployment Status | DevOps Agent Detection |
|----------|-----------|-------------------|----------------------|
| 1 | Build Failure | Failed | Deployment event + Build logs |
| 2 | Runtime Failure | Succeeded | Deployment event + CloudWatch logs |
| 3 | Security Issue | Succeeded | Code review via GitHub access |

## Key DevOps Agent Capabilities Demonstrated

1. **GitHub Integration**
   - Receives deployment events automatically
   - Read-only access to repository contents
   - Correlates code changes with operational incidents

2. **Deployment Correlation**
   - Links recent deployments to service issues
   - Shows commit details and changed files
   - Identifies which code changes might have caused problems

3. **Log Analysis**
   - Retrieves CloudWatch logs for affected services
   - Correlates error messages with code changes
   - Provides context for troubleshooting

4. **Security Awareness**
   - Can scan commits for credential patterns
   - Flags security concerns in code changes
   - Recommends secure alternatives (Secrets Manager, SSM)

## Cleanup

After the workshop, clean up resources:

```bash
# Delete CloudFormation stack
aws cloudformation delete-stack --stack-name Observability-Workshop

# Remove GitHub app (optional)
# Go to GitHub Settings → Applications → Installed GitHub Apps → AWS DevOps Agent → Uninstall
```
