#!/bin/bash
# Scenario 3: Security Vulnerability - Exposed Credentials in Code
# This script injects hardcoded credentials to demonstrate security scanning
#
# DevOps Agent GitHub Integration Demo:
# - DevOps Agent has read-only access to repository contents
# - Can scan commits for credential patterns
# - Flags security concerns and recommends Secrets Manager/SSM

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
APP_YML="$REPO_ROOT/PetAdoptions/petsearch-java/src/main/resources/application.yml"
SECRETS_FILE="$REPO_ROOT/PetAdoptions/petsearch-java/src/main/resources/secrets.properties"

echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║  Scenario 3: Security Vulnerability - Exposed Credentials        ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""
echo "📋 Story: A developer accidentally commits configuration files with"
echo "          hardcoded API keys and database credentials"
echo ""

# Backup original application.yml
cp "$APP_YML" "$APP_YML.backup"

# Create new application.yml with injected credentials
cat > "$APP_YML" << 'EOF'
server:
  port: 80

# SECURITY VULNERABILITY: Hardcoded credentials below
# These should be stored in AWS Secrets Manager or SSM Parameter Store!

external:
  api:
    # Production API key - NEVER commit secrets to source control!
    key: "sk-prod-abc123xyz789secretkey"
    endpoint: "https://api.external-service.com"
    
# Database connection credentials (INSECURE!)
database:
  host: "prod-database.cluster-xyz.us-east-1.rds.amazonaws.com"
  port: 5432
  name: "petadoptions"
  username: "admin"
  password: "SuperSecretProdPassword123!"

logging:
  level:
    root: INFO
    ca.petsearch: DEBUG
EOF

# Create secrets.properties file with fake credentials
cat > "$SECRETS_FILE" << 'EOF'
# ============================================================
# SECURITY VULNERABILITY: This file should NOT be committed!
# Add secrets.properties to .gitignore immediately!
# ============================================================

# Database credentials
db.username=admin
db.password=SuperSecret123!
db.host=prod-database.cluster-xyz.us-east-1.rds.amazonaws.com

# AWS credentials (CRITICAL: Never commit AWS credentials!)
aws.access.key=AKIAIOSFODNN7EXAMPLE
aws.secret.key=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
aws.region=us-east-1

# Third-party API keys
stripe.api.key=sk_live_abc123xyz789
stripe.webhook.secret=whsec_abc123xyz789
sendgrid.api.key=SG.abcdefghijklmnop
twilio.auth.token=abc123xyz789authtoken
EOF

echo "✅ Injection complete!"
echo ""
echo "📁 Files created/modified:"
echo "   - application.yml (added hardcoded API key and database credentials)"
echo "   - secrets.properties (new file with AWS and third-party credentials)"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📤 Push the change to trigger the pipeline:"
echo ""
echo "   git add -A"
echo "   git commit -m 'feat: add external service configuration'"
echo "   git push origin main"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "⚠️  The pipeline will SUCCEED (no build errors), but this introduces"
echo "   serious security vulnerabilities:"
echo ""
echo "   🔴 Hardcoded API keys in application.yml"
echo "   🔴 Database credentials in plain text"
echo "   🔴 AWS credentials in source code"
echo "   🔴 Third-party API keys (Stripe, SendGrid, Twilio)"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🔍 DevOps Agent Investigation Prompt:"
echo ""
echo "   'Review the recent commits to the PetAdoptions repository."
echo "    Check if any sensitive information like API keys, passwords,"
echo "    or AWS credentials have been committed to the codebase.'"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🛠️  To fix: ./workshop-scenarios/scenario3-security-issue/fix.sh"
