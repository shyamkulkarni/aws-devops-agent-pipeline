#!/bin/bash
# Deploy One Observability Workshop to AWS
# This script creates a modified CloudFormation template and deploys it

set -e

STACK_NAME="DevOpsAgent-Pipeline-Workshop"
REGION="us-east-1"
GITHUB_USER="shyamkulkarni"
GITHUB_REPO="devops-agent-pipeline-integration"
USER_ROLE_ARN="arn:aws:iam::466162272783:user/kulkshya"

echo "Creating modified CloudFormation template..."

# Create modified template with correct repo name and paths
TEMPLATE_FILE="/tmp/codepipeline-stack-modified.yaml"
sed -e 's|one-observability-demo\.git|devops-agent-pipeline-integration.git|g' \
    -e 's|/one-observability-demo/|/devops-agent-pipeline-integration/|g' \
    "$(dirname "$0")/codepipeline-stack.yaml" > "$TEMPLATE_FILE"

echo "Deploying stack: $STACK_NAME"
echo "Region: $REGION"
echo "GitHub: $GITHUB_USER/$GITHUB_REPO"

aws cloudformation create-stack \
  --stack-name "$STACK_NAME" \
  --template-body "file://$TEMPLATE_FILE" \
  --capabilities CAPABILITY_NAMED_IAM \
  --parameters \
    ParameterKey=UserRoleArn,ParameterValue="$USER_ROLE_ARN" \
    ParameterKey=GithubUser,ParameterValue="$GITHUB_USER" \
    ParameterKey=GithubBranch,ParameterValue=main \
  --region "$REGION"

echo ""
echo "Stack creation initiated!"
echo "Monitor progress: aws cloudformation describe-stack-events --stack-name $STACK_NAME --region $REGION"
echo ""
echo "Cleaning up temp file..."
rm -f "$TEMPLATE_FILE"

echo "Done!"
