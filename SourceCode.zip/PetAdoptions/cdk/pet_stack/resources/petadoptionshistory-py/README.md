# PetAdoptionsHistory with full OTEL instrumentation applied

See PetAdoptions/petadoptionshistory-py/ for the complete source code of the service.

* `petadoptionshistory_tracing.py`: tracing applied
* `petadoptionshistory_complete.py`: tracing and metrics applied