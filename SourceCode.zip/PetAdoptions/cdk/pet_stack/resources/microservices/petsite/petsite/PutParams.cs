namespace PetSite
{
    public class PutParams
    {
        public string petid { get; set; }
        public string pettype { get; set; }
    }
}